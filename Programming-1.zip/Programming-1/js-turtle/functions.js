// Escreve aqui o teu código com a turtle.
// Exemplo: forward(50); right(90);
